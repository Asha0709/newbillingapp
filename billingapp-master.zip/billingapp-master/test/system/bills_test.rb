require "application_system_test_case"

class BillsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit bills_url
  #
  #   assert_selector "h1", text: "Bill"
  # end
end
